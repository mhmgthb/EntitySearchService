package sa.qiwa.cache.search.ms.foundation.config;

public interface IEntitySearchConfiguration {

}
