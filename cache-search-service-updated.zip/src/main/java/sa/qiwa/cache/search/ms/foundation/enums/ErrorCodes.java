package sa.qiwa.cache.search.ms.foundation.enums;

public enum ErrorCodes {
    BAD_REQUEST,
    NOT_FOUND,
    BUSINESS_VALIDATION,  // 405
    UNKNOWN,

}
